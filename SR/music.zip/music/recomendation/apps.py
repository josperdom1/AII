from django.apps import AppConfig


class RecomendationConfig(AppConfig):
    name = 'recomendation'
